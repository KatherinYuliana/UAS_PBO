package Modul3.Mahasiswa;

import java.util.List;
import Modul3.MataKuliah.MataKuliah;

public class Magister extends Mahasiswa{
    private List<MataKuliah> listMataKuliah;
    private String judulPenelitianTesis;

    public Magister(String name, String address, String TTL, String telephone, String NIM, String jurusan, List<MataKuliah> listMataKuliah, String judulPenelitianTesis) {
        super(name, address, TTL, telephone, NIM, jurusan);
        this.listMataKuliah = listMataKuliah;
        this.judulPenelitianTesis = "Judul Penelitian";
    }

    public List<MataKuliah> getListMataKuliah() {
        return listMataKuliah;
    }

    public void setListMataKuliah(List<MataKuliah> listMataKuliah) {
        this.listMataKuliah = listMataKuliah;
    }

    public String getJudulPenelitianTesis() {
        return judulPenelitianTesis;
    }

    public void setJudulPenelitianTesis(String judulPenelitianTesis) {
        this.judulPenelitianTesis = judulPenelitianTesis;
    }

    @Override
    public String toString() {
        return "Nama Mahasiswa: " + getNama() + 
                "\nAlamat: " + getAlamat() + 
                "\nTTL: " + getTTL() + 
                "\nNo Telepon: " + getTelephone() + 
                "\nNIM: " + getNIM() +
                "\nJurusan: " + getJurusan() +
                "\nList Matkul: " + getListMataKuliah() +
                "\nJudul Penelitian Tesis: " + judulPenelitianTesis;
    }
}
