package Modul3.Mahasiswa;

import java.util.List;

import Modul3.MataKuliah.MataKuliah;

public class Sarjana extends Mahasiswa{
    private List<MataKuliah> listMataKuliah;

    public Sarjana(String name, String address, String TTL, String telephone, String NIM, String jurusan, List<MataKuliah> listMataKuliah) {
        super(name, address, TTL, telephone, NIM, jurusan);
        this.listMataKuliah = listMataKuliah;
    }

    public List<MataKuliah> getListMataKuliah() {
        return listMataKuliah;
    }

    public void setListMataKuliah(List<MataKuliah> listMataKuliah) {
        this.listMataKuliah = listMataKuliah;
    }

    @Override
    public String toString() {
        return "Nama Mahasiswa: " + getNama() + 
                "\nAlamat: " + getAlamat() + 
                "\nTTL: " + getTTL() + 
                "\nNo Telepon: " + getTelephone() + 
                "\nNIM: " + getNIM() +
                "\nJurusan: " + getJurusan() +
                "\nList Matkul: " + getListMataKuliah();
    }
}
