package Modul3;

public class User {
    String nama;
    String alamat;
    String ttl;
    String telp;

    public User(String nama, String alamat, String ttl, String telp) {
        this.nama = "Katherin";
        this.alamat ="Bandung";
        this.ttl = "8 Juli 2004";
        this.telp = "0123456789";
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getTTL() {
        return ttl;
    }

    public void setTTL(String ttl) {
        this.ttl = ttl;
    }

    public String getTelephone() {
        return telp;
    }

    public void setTelephone(String telp) {
        this.telp = telp;
    }
}
