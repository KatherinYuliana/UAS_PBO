package Modul3;

import java.util.Scanner;
import Modul3.Mahasiswa.*;
import Modul3.Staff.Karyawan;
import Modul3.Staff.Dosen.*;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Menu Login: \n1. Mahasiswa \n2. Staff");
        int login = scan.nextInt();

        if(login == 1){
            System.out.println("---------------------------");
            System.out.println("Program: \n1. Sarjana \n2. Magister \n3. Doktor");
            int program = scan.nextInt();

            if(program == 1){
                Sarjana sarjana = new Sarjana(null, null, null, null, null, null, null);
                System.out.println("---------------------------");
                System.out.println(sarjana);
            } else if(program == 2){
                Magister magister = new Magister(null, null, null, null, null, null, null, null);
                System.out.println("---------------------------");
                System.out.println(magister);
            } else {
                Doktor doktor = new Doktor(null, null, null, null, null, null, null, program, login, program);
                System.out.println("---------------------------");
                System.out.println(doktor);
            }

        } else {
            System.out.println("---------------------------");
            System.out.println("Staff: \n1. Dosen \n2.Karyawan");
            int staff = scan.nextInt();

            if(staff == 1){
                System.out.println("---------------------------");
                System.out.println("Dosen: \n1. Tetap \n2. Honorer");
                int dosen = scan.nextInt();

                if(dosen == 1){
                    DosenTetap tetap = new DosenTetap(null, null, null, null, null, null, null, dosen);
                    System.out.println("---------------------------");
                    System.out.println(tetap);
                } else {
                    Honorer honorer = new Honorer(null, null, null, null, null, null, null, dosen);
                    System.out.println("---------------------------");
                    System.out.println(honorer);
                }

            } else {
                Karyawan karyawan = new Karyawan(null, null, null, null, null, staff, null);
                System.out.println("---------------------------");
                System.out.println(karyawan);
            }
        }
    }
}
