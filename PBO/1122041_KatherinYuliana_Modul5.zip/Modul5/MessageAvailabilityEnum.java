package Modul5;

public enum MessageAvailabilityEnum {
    AVAILABLE, DELETED;
}
