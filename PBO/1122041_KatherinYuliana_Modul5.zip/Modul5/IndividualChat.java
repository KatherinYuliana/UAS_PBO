package Modul5;

public class IndividualChat extends Chat{
    private String friendUsername;

    public User getFriend() {
        return null;
    }
}
