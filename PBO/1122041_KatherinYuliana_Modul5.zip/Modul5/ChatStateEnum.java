package Modul5;

public enum ChatStateEnum {
    PINNED, UNPINNED, MUTED, UNMUTED, HIDE, DELETED;

    public void pinChat(Chat chat) {
    }

    public void unpinChat(Chat chat) {
    }

    public void muteChat(Chat chat) {
    }

    public void unmuteChat(Chat chat) {
    }
}
