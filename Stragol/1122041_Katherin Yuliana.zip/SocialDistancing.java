package Stragol;

import java.util.Scanner;

public class SocialDistancing {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Masukkan n: ");
        int n = scam.nextInt;
        System.out.println("Masukkan i: ");
        int i = scan.nextInt();
        int a[] = new int[n];

        for(int i = 0; i < n; i++){
            System.out.println("Masukkan n: ");
            a[i] = scan.nextInt;
        }
    }
}
